/**
 * Created by Administrator on 2016/11/28.
 */
angular.module('refreshApp',['ionic','ngAnimate'])
    .config(function ($stateProvider,$urlRouterProvider,$ionicConfigProvider) {
        $ionicConfigProvider.tabs.position("bottom");

        $stateProvider
            .state('start', {
                url: '/start',
                templateUrl: 'tpl/start.html'
            })
            .state('index', {
                url: '/index',
                templateUrl: 'tpl/index.html',
                controller:'indexCtrl'
            })
            .state('user', {
                url:'/user',
                templateUrl: 'tpl/user.html',
                controller:'userCtrl'
            })
            .state('cart', {
                url:'/cart',
                templateUrl: 'tpl/cart.html'

            })
            .state('about', {
                url:'/about',
                templateUrl: 'tpl/about.html'

            })
            .state('productlist', {
                url:'/productlist',
                templateUrl: 'tpl/productlist.html'

            })
            .state('productdetail', {
                url:'/productdetail',
                templateUrl: 'tpl/productdetail.html'

            });
        $urlRouterProvider.otherwise('index');
    })
    .controller('parentCtrl',
    ['$scope','$state','$ionicSideMenuDelegate','$ionicSlideBoxDelegate','$ionicModal',
        function ($scope,$state,$ionicSideMenuDelegate,$ionicSlideBoxDelegate,$ionicModal) {
            //��ת����
            $scope.jump = function (arg) {
                $state.go(arg);
            }
            //ҳ���ֲ��ĵ����л�
            $scope.pageClick = function(index) {
                console.log(index);
                $ionicSlideBoxDelegate.slide(index);
            }
            //����������
            $ionicModal.fromTemplateUrl('modal.html', {
                scope: $scope,
                animation: 'slide-in-right'
            }).then(function(modal) {
                $scope.modal = modal;
            });
            $scope.search = function() {
                $scope.modal.show();
            };

        }
    ])
    .controller('indexCtrl',['$scope','$http','$timeout',
        function($scope,$http,$timeout){
            $scope.hasMore = true;
            $scope.pageNum = 1;
            //��ȡ��ʼ����������
            $http.get('data/news_select.php?pageNum='+$scope.pageNum)
                .success(function (newsData) {
                    $scope.newsList = newsData.data;
                    $scope.pageNum++;
                });
            //���ظ���
            $scope.loadMore = function () {
                $timeout(function () {
                    console.log($scope.pageNum);
                    console.log($scope.hasMore);
                    $http.get('data/news_select.php?pageNum='+$scope.pageNum)
                        .success(function (newsData) {
                            if(newsData.data.length <7)
                            {
                                $scope.hasMore = false;
                            }
                            $scope.newsList = $scope.newsList.concat(newsData.data);
                            $scope.pageNum++;
                            $scope.$broadcast('scroll.infiniteScrollComplete');
                        })
                },2000);
            };

            //����
            $scope.inputTxt = {kw:''};
            $scope.$watch('inputTxt.kw', function () {
                console.log($scope.inputTxt.kw);
                if($scope.inputTxt.kw)
                {
                    $http
                        .get('data/product_search.php?kw='+$scope.inputTxt.kw)
                        .success(function (result) {
                            $scope.searchList = result.data;
                        })
                }

            })

        }
    ])
    .controller('userCtrl',['$scope',
        function($scope){
            $scope.data='456';
        }
    ])
